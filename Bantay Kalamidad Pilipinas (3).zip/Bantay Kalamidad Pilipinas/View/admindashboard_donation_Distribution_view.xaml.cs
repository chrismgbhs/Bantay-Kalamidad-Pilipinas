﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Bantay_Kalamidad_Pilipinas.View
{
    /// <summary>
    /// Interaction logic for admindashboard_donation_Distribution_view.xaml
    /// </summary>
    public partial class admindashboard_donation_Distribution_view : UserControl
    {
        public admindashboard_donation_Distribution_view()
        {
            InitializeComponent();
        }
    }
}
