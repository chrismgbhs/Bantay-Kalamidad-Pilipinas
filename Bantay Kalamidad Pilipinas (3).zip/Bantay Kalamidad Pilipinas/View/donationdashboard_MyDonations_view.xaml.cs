﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Bantay_Kalamidad_Pilipinas.View
{
    /// <summary>
    /// Interaction logic for donationdashboard_MyDonations_view.xaml
    /// </summary>
    public partial class donationdashboard_MyDonations_view : UserControl
    {
        public donationdashboard_MyDonations_view()
        {
            InitializeComponent();
            this.DataContext = new ViewModel.donationdashboard_MyDonations_ViewModel();
        }
    }
}
